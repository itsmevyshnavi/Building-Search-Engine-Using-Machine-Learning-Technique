from django.apps import AppConfig


class SearchengineappConfig(AppConfig):
    name = 'SearchEngineApp'
